# Global Currency Exchange & UPI Transfer - Backend
Node.js + Express REST API.
```
npm install
npm start
```
Endpoints: GET /api/rates, GET /api/convert?from=USD&to=INR&amount=10, GET /api/account/:upi, POST /api/transfer, GET /api/transactions
