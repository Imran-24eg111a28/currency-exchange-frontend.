// Global Currency Exchange + UPI-style money transfer (demo backend)
const express = require("express");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(express.json());

// Fallback rates (base USD) used if the live API is unreachable
let rates = { USD: 1, INR: 83.2, EUR: 0.92, GBP: 0.79, JPY: 149.5, AED: 3.67, AUD: 1.53, CAD: 1.36, SGD: 1.34 };
let source = "fallback";

async function refreshRates() {
  try {
    const r = await fetch("https://open.er-api.com/v6/latest/USD");
    const d = await r.json();
    if (d.rates) { rates = d.rates; source = "live"; }
  } catch (e) { console.log("Using fallback rates"); }
}
refreshRates();
setInterval(refreshRates, 60 * 60 * 1000);

// Demo accounts: UPI-style IDs with wallet balances
const accounts = {
  "imran@upi": { name: "Imran", currency: "INR", balance: 50000 },
  "john@usbank": { name: "John", currency: "USD", balance: 1000 },
  "emma@ukbank": { name: "Emma", currency: "GBP", balance: 800 },
};
const transactions = [];
const convert = (amt, from, to) => (amt / rates[from]) * rates[to];

app.get("/api/rates", (req, res) => res.json({ base: "USD", source, rates }));

app.get("/api/convert", (req, res) => {
  const { from, to, amount } = req.query;
  if (!rates[from] || !rates[to] || isNaN(amount)) return res.status(400).json({ error: "Invalid input" });
  res.json({ from, to, amount: +amount, result: +convert(+amount, from, to).toFixed(2) });
});

app.get("/api/account/:upi", (req, res) => {
  const a = accounts[req.params.upi];
  a ? res.json({ upi: req.params.upi, ...a }) : res.status(404).json({ error: "UPI ID not found" });
});

app.post("/api/transfer", (req, res) => {
  const { from, to, amount, pin } = req.body;
  const s = accounts[from], r = accounts[to];
  if (!s || !r) return res.status(404).json({ error: "UPI ID not found" });
  if (pin !== "1234") return res.status(401).json({ error: "Wrong PIN (demo PIN: 1234)" });
  if (!(amount > 0) || amount > s.balance) return res.status(400).json({ error: "Invalid or insufficient amount" });
  const received = +convert(amount, s.currency, r.currency).toFixed(2);
  const fee = +(amount * 0.005).toFixed(2); // 0.5% demo fee
  s.balance = +(s.balance - amount - fee).toFixed(2);
  r.balance = +(r.balance + received).toFixed(2);
  const tx = { id: "TXN" + Date.now(), from, to, sent: amount, sentCurrency: s.currency,
    received, receivedCurrency: r.currency, fee, time: new Date().toISOString(), status: "SUCCESS" };
  transactions.unshift(tx);
  res.json(tx);
});

app.get("/api/transactions", (req, res) => res.json(transactions));

app.listen(process.env.PORT || 5000, () => console.log("Backend running on port 5000"));
